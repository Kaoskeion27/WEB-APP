**CID:** [01553781]

# Project
This repository is for the submission of your **Computing 2: Applications** coursework.

You should complete the proforma and populate this repository with your project submission.

* **Repository Creation Check:** Tuesday 4th May 18:00 – Update your CID in this file to check your submission.
* **Peer Assessment Deadline:** Tuesday 8th June 18:00
* **Final Submission Deadline:** Thursday 17th June 16:00

# Computing 2 Submission Proforma

For each section, write a maximum of 200 words.

## Brief
I love movies, from directing to cinematography, from acting to award ceremonies, movies are a visual and audio experience that can truly cause a person to reflect on their being and purpose. Therefore, for this project, I wanted to share my passion with others by challenging their movie knowledge with the ultimate movie quiz! The quiz allows users to choose between 1 of 4 answers, with a questions that truly confronts them on their cinematic conaissance. Each question is shuffled before being sent to the user, with each of them ranging from mainstream movie quotes to deep dives into the film world. Scorsese, Di Caprio, Hugh Jackman are just some names you will encounter on your race to the finish! No matter how badly the odds are stacked against you, never let them tell you.

## Coding
In terms of coding, it was essential that their was a smooth interaction between the back-end and front-end sides of the project. I therefore started with setting up a proper, attractive layout for my users to interact with, followed by some hard coding via javascript. As I did not want to have a several boxes for each phase of the quiz (start, rules and regulations, questions, results), I created a class called 'hide' in my index.html, and then, on my css, attributed this class a 'display: none'. This allowed me to easily transition from showing elements and hiding elements on my js as the game went one. I also implemented a scoreCounter function that could increment the user's score at the end of the game. Additionaly, I create an onclick restart button that would permit users to restart if they were not satisfied with their scores, leading them back to the rules and regulation page.

## UX/UI
In terms of my UX/UI design, as is the case in movies, it is not one feature that creates an enjoyable experience, but an accumulation of unnoticeable minute features that subconsciously create an unforgettable experience. Using CSS, I was able to add hover functions over my buttons as well as choosing a color palette that was not overwhelming to the user. Furthermore, an additional feature of changing background color was implemented so that the user was rewarded with success.

## Data
In terms of data structuring, my main functions are contained in my main.js file but some other functions such as scoreCounter were place in individual files. Initially, my array of questions and answers were placed in the static folder, but thanks to ajax and a handler, I was able to store them in a handler.js file that when requested, would deliver the questions to the functionality file through the server. This allowed for my web-app to have both UX and server interaction.

## Debugging
Through trial and error, many functions gained life as the project went on. JSlint also provided me with a way to make my code more efficient and less cluttered, removing trailing whitespaces, forgetting semi-colons etc... Another key element that featured prominently in my debugging was the inspector on firefox. This allowed me to identify whether or not the correct class or function displayed, and helped me pinpoint errors inn my code. Moreover, through console.logging, I was able to see if my desired output information was being provided.

## Best Practice
By best practices, commenting enabled a better understanding of the js script whilst granting clarification on its functionality. Additionaly, using tests via mocha and fast-check permitted me to rework and fill any loopholes contained within my code. Overall it was an arduous but very interesting project and I can only look forward to what is to come in the future years. 

